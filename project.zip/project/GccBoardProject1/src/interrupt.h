/*
 * interrupt.h
 *
 * Created: 2017-11-18 2:11:12 PM
 *  Author: abates
 */ 


#ifndef INTERRUPT_H_
#define INTERRUPT_H_

void init_interrupt();

#endif /* INTERRUPT_H_ */