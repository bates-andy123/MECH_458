import numpy as np
import sys
import serial

try:
	filename = sys.argv[1]
except IndexError:
	filename = "default_name.csv"

con = serial.Serial(
	port='COM3',
	baudrate=9600,
	#parity=serial.None,
	stopbits=serial.STOPBITS_ONE,
	bytesize=serial.EIGHTBITS
)

file = open(filename,'w')
file.write("Reading Num, ADC value\r\n")

data = []
i =0

max1 = 0
max2 = 0
max3 = 0

try:
	while True:
		if(con.in_waiting >= 4):
			x = con.read(4)
			file.write(str(i) + ',' + x.decode("utf-8") + '\n')
			data.append(x)
			if(i < 20):
				x = int(x)
				if x > max1:
					max3 = max2
					max2 = max1
					max1= x
				elif x > max2:
					max3 = max2
					max2 = x
				elif x > max3:
					max3 = x
			elif i == 20:
				print(max1)
				print(max2)
				print(max3)
			i += 1
except KeyboardInterrupt:
	pass
	
file.close()
	
print("Mean: " + str(np.mean(data)))
print("Stddev: " + str(np.std(data)))
print("Min: " + str(np.min(data)))
print("Max: " + str(np.max(data)))